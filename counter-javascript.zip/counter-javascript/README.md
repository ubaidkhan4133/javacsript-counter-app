# counter javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/script-hacker/pen/WNVoEYa](https://codepen.io/script-hacker/pen/WNVoEYa).

